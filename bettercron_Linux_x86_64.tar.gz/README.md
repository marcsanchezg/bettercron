# bettercron
A better cron alternative, written in go to learn and practise
